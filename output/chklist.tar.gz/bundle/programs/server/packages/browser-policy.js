(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var BrowserPolicy = Package['browser-policy-common'].BrowserPolicy;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['browser-policy'] = {};

})();
