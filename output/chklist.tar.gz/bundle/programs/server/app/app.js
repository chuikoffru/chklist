var require = meteorInstall({"imports":{"api":{"reports":{"collection.js":["meteor/mongo",function(require,exports){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/api/reports/collection.js                                                                //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
Object.defineProperty(exports, '__esModule', {                                                      //
  value: true                                                                                       //
});                                                                                                 //
                                                                                                    //
var _meteorMongo = require('meteor/mongo');                                                         //
                                                                                                    //
var Reports = new _meteorMongo.Mongo.Collection('reports');                                         // 3
                                                                                                    //
exports.Reports = Reports;                                                                          //
Reports.allow({                                                                                     // 5
  insert: function insert(userId, report) {                                                         // 6
    return true;                                                                                    // 7
  },                                                                                                //
  update: function update(userId, report, fields, modifier) {                                       // 9
    return true;                                                                                    // 10
  },                                                                                                //
  remove: function remove(userId, report) {                                                         // 12
    return true;                                                                                    // 13
  }                                                                                                 //
});                                                                                                 //
//////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./publish","./collection",function(require,exports){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/api/reports/index.js                                                                     //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
Object.defineProperty(exports, '__esModule', {                                                      //
  value: true                                                                                       //
});                                                                                                 //
                                                                                                    //
function _interopExportWildcard(obj, defaults) { var newObj = defaults({}, obj); delete newObj['default']; return newObj; }
                                                                                                    //
function _defaults(obj, defaults) { var keys = Object.getOwnPropertyNames(defaults); for (var i = 0; i < keys.length; i++) { var key = keys[i]; var value = Object.getOwnPropertyDescriptor(defaults, key); if (value && value.configurable && obj[key] === undefined) { Object.defineProperty(obj, key, value); } } return obj; }
                                                                                                    //
require('./publish');                                                                               //
                                                                                                    //
var _collection = require('./collection');                                                          //
                                                                                                    //
_defaults(exports, _interopExportWildcard(_collection, _defaults));                                 //
//////////////////////////////////////////////////////////////////////////////////////////////////////

}],"publish.js":["meteor/meteor","./collection",function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/api/reports/publish.js                                                                   //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
var _meteorMeteor = require('meteor/meteor');                                                       //
                                                                                                    //
var _collection = require('./collection');                                                          //
                                                                                                    //
if (_meteorMeteor.Meteor.isServer) {                                                                // 5
  _meteorMeteor.Meteor.publish('reports', function (options) {                                      // 6
    return _collection.Reports.find({});                                                            // 7
  });                                                                                               //
                                                                                                    //
  _meteorMeteor.Meteor.publish('fullReports', function (options) {                                  // 10
    var selector = {};                                                                              // 11
    return _collection.Reports.find(selector, options);                                             // 12
  });                                                                                               //
}                                                                                                   //
//////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"shops":{"collection.js":["meteor/mongo",function(require,exports){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/api/shops/collection.js                                                                  //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
Object.defineProperty(exports, '__esModule', {                                                      //
  value: true                                                                                       //
});                                                                                                 //
                                                                                                    //
var _meteorMongo = require('meteor/mongo');                                                         //
                                                                                                    //
var Shops = new _meteorMongo.Mongo.Collection('shops');                                             // 3
                                                                                                    //
exports.Shops = Shops;                                                                              //
Shops.allow({                                                                                       // 5
  insert: function insert(userId, shop) {                                                           // 6
    return true; //userId && shop.owner === userId;                                                 // 7
  },                                                                                                //
  update: function update(userId, shop, fields, modifier) {                                         // 9
    return true; //userId && shop.owner === userId;                                                 // 10
  },                                                                                                //
  remove: function remove(userId, shop) {                                                           // 12
    return true; // userId && shop.owner === userId;                                                // 13
  }                                                                                                 //
});                                                                                                 //
//////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./publish","./collection",function(require,exports){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/api/shops/index.js                                                                       //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
Object.defineProperty(exports, '__esModule', {                                                      //
  value: true                                                                                       //
});                                                                                                 //
                                                                                                    //
function _interopExportWildcard(obj, defaults) { var newObj = defaults({}, obj); delete newObj['default']; return newObj; }
                                                                                                    //
function _defaults(obj, defaults) { var keys = Object.getOwnPropertyNames(defaults); for (var i = 0; i < keys.length; i++) { var key = keys[i]; var value = Object.getOwnPropertyDescriptor(defaults, key); if (value && value.configurable && obj[key] === undefined) { Object.defineProperty(obj, key, value); } } return obj; }
                                                                                                    //
require('./publish');                                                                               //
                                                                                                    //
var _collection = require('./collection');                                                          //
                                                                                                    //
_defaults(exports, _interopExportWildcard(_collection, _defaults));                                 //
//////////////////////////////////////////////////////////////////////////////////////////////////////

}],"publish.js":["meteor/meteor","./collection",function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/api/shops/publish.js                                                                     //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
var _meteorMeteor = require('meteor/meteor');                                                       //
                                                                                                    //
var _collection = require('./collection');                                                          //
                                                                                                    //
if (_meteorMeteor.Meteor.isServer) {                                                                // 5
  _meteorMeteor.Meteor.publish('shops', function () {                                               // 6
    /*const selector = {                                                                            //
      $or: [{                                                                                       //
        $and: [{                                                                                    //
          public: true                                                                              //
        }, {                                                                                        //
          public: {                                                                                 //
            $exists: true                                                                           //
          }                                                                                         //
        }]                                                                                          //
      }, {                                                                                          //
        $and: [{                                                                                    //
          owner: this.userId                                                                        //
        }, {                                                                                        //
          owner: {                                                                                  //
            $exists: true                                                                           //
          }                                                                                         //
        }]                                                                                          //
      }]                                                                                            //
    };*/                                                                                            //
                                                                                                    //
    return _collection.Shops.find({});                                                              // 27
  });                                                                                               //
}                                                                                                   //
//////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"users":{"index.js":["meteor/meteor",function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/api/users/index.js                                                                       //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
var _meteorMeteor = require('meteor/meteor');                                                       //
                                                                                                    //
_meteorMeteor.Meteor.users.allow({                                                                  // 3
  insert: function insert(userId) {                                                                 // 4
    return true;                                                                                    // 5
  },                                                                                                //
  update: function update(userId, fields, modifier) {                                               // 7
    return true;                                                                                    // 8
  }                                                                                                 //
});                                                                                                 //
                                                                                                    //
if (_meteorMeteor.Meteor.isServer) {                                                                // 12
  _meteorMeteor.Meteor.publish('users', function () {                                               // 13
    return _meteorMeteor.Meteor.users.find({});                                                     // 14
  });                                                                                               //
                                                                                                    //
  _meteorMeteor.Meteor.publish('usersList', function () {                                           // 17
    return _meteorMeteor.Meteor.users.find({                                                        // 18
      roles: { $in: "user" }                                                                        // 19
    });                                                                                             //
  });                                                                                               //
}                                                                                                   //
//////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},"server":{"shops.js":["meteor/meteor","../imports/api/shops",function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// server/shops.js                                                                                  //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
var _meteorMeteor = require('meteor/meteor');                                                       //
                                                                                                    //
var _importsApiShops = require('../imports/api/shops');                                             //
                                                                                                    //
_meteorMeteor.Meteor.methods({                                                                      // 4
  addQuestion: function addQuestion(check, shop, question) {                                        // 5
    _importsApiShops.Shops.update({ _id: shop._id, 'checklists.name': check.name }, { $push: { 'checklists.$.questions': question } });
  },                                                                                                //
  removeQuestion: function removeQuestion(id, item) {                                               // 8
    delete item.$$hashKey;                                                                          // 9
    _importsApiShops.Shops.update({ _id: id._id, 'checklists.questions.title': item.title }, { $pull: { 'checklists.$.questions': item } });
  },                                                                                                //
  setPosition: function setPosition(id, item, position) {                                           // 12
    console.log(id, item, position);                                                                // 13
    /*Shops.update({_id : id, 'checklists.questions.title' : item.title, 'checklists.questions.position' : item.position}, {
    	$inc : {                                                                                       //
    		'checklists.$.questions.0.position' : position                                                //
    	}                                                                                              //
    });*/                                                                                           //
  }                                                                                                 //
});                                                                                                 //
//////////////////////////////////////////////////////////////////////////////////////////////////////

}],"users.js":["meteor/meteor","meteor/accounts-base","meteor/alanning:roles",function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// server/users.js                                                                                  //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
var _meteorMeteor = require('meteor/meteor');                                                       //
                                                                                                    //
var _meteorAccountsBase = require('meteor/accounts-base');                                          //
                                                                                                    //
var _meteorAlanningRoles = require('meteor/alanning:roles');                                        //
                                                                                                    //
_meteorMeteor.Meteor.methods({                                                                      // 5
  addNewUser: function addNewUser(data) {                                                           // 6
                                                                                                    //
    var id = undefined;                                                                             // 8
                                                                                                    //
    if (_meteorAlanningRoles.Roles.userIsInRole(_meteorMeteor.Meteor.userId(), 'admin')) {          // 10
      console.log("You are admin");                                                                 // 12
      id = _meteorAccountsBase.Accounts.createUser(data);                                           // 13
                                                                                                    //
      if (id) {                                                                                     // 15
        _meteorAlanningRoles.Roles.setUserRoles(id, data.roles);                                    // 16
        console.log('YES');                                                                         // 17
      } else {                                                                                      //
        console.log('NO');                                                                          // 19
      }                                                                                             //
    } else {                                                                                        //
      id = null;                                                                                    // 23
      console.log('No permission');                                                                 // 24
    }                                                                                               //
                                                                                                    //
    return id;                                                                                      // 27
  },                                                                                                //
  getUserByEmail: function getUserByEmail(email) {                                                  // 29
    return _.pick(_meteorAccountsBase.Accounts.findUserByEmail(email), '_id', 'profile', 'emails');
  }                                                                                                 //
});                                                                                                 //
//////////////////////////////////////////////////////////////////////////////////////////////////////

}],"main.js":["meteor/meteor","../imports/api/shops","../imports/api/reports","../imports/api/users",function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// server/main.js                                                                                   //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
var _meteorMeteor = require('meteor/meteor');                                                       //
                                                                                                    //
var _importsApiShops = require('../imports/api/shops');                                             //
                                                                                                    //
require('../imports/api/reports');                                                                  //
                                                                                                    //
require('../imports/api/shops');                                                                    //
                                                                                                    //
require('../imports/api/users');                                                                    //
                                                                                                    //
//Roles.addUsersToRoles("AHWfjoPiQspcYARsN", 'admin');                                              //
                                                                                                    //
_meteorMeteor.Meteor.startup(function () {                                                          // 9
  if (_importsApiShops.Shops.find().count() === 0) {                                                // 10
    var shops = [{                                                                                  // 11
      'name': 'Камчадалочка',                                                                       // 12
      'address': 'ул. Владивостокская, 47',                                                         // 13
      'checklists': [],                                                                             // 14
      "owner": "AHWfjoPiQspcYARsN",                                                                 // 15
      'active': 1                                                                                   // 16
    }, {                                                                                            //
      'name': 'ТЦ Евразия',                                                                         // 18
      'address': 'ул. Кавказская, 49',                                                              // 19
      'checklists': [],                                                                             // 20
      "owner": "AHWfjoPiQspcYARsN",                                                                 // 21
      'active': 1                                                                                   // 22
    }, {                                                                                            //
      'name': 'ТЦ Вега',                                                                            // 24
      'address': 'ул. Пограничная, 13',                                                             // 25
      'checklists': [],                                                                             // 26
      "owner": "AHWfjoPiQspcYARsN",                                                                 // 27
      'active': 1                                                                                   // 28
    }, {                                                                                            //
      'name': 'Елизово',                                                                            // 30
      'address': 'ул. Ленина, 21',                                                                  // 31
      'checklists': [],                                                                             // 32
      "owner": "AHWfjoPiQspcYARsN",                                                                 // 33
      'active': 1                                                                                   // 34
    }];                                                                                             //
                                                                                                    //
    shops.forEach(function (shop) {                                                                 // 37
      _importsApiShops.Shops.insert(shop);                                                          // 38
    });                                                                                             //
  }                                                                                                 //
});                                                                                                 //
//////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/shops.js");
require("./server/users.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
