(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var BrowserPolicy = Package['browser-policy-common'].BrowserPolicy;

/* Package-scope variables */
var Ucare, Future;

var require = meteorInstall({"node_modules":{"meteor":{"smalljoys:uploadcare":{"ucare.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/smalljoys_uploadcare/ucare.js                                                                 //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
Ucare = {};                                                                                               // 1
                                                                                                          //
Ucare.store = function (image, callback) {                                                                // 3
  Meteor.call('addToMediaStorage', image, function (err, res) {                                           // 4
    if (typeof callback === "function") {                                                                 // 5
      if (err) {                                                                                          // 6
        return callback(err, null);                                                                       // 7
      }                                                                                                   //
      return callback(null, res);                                                                         // 9
    }                                                                                                     //
  });                                                                                                     //
};                                                                                                        //
                                                                                                          //
Ucare['delete'] = function (image, callback) {                                                            // 14
  Meteor.call('removeFromMediaStorage', image, function (err, res) {                                      // 15
    if (typeof callback === "function") {                                                                 // 16
      if (err) {                                                                                          // 17
        return callback(err, null);                                                                       // 18
      }                                                                                                   //
      return callback(null, res);                                                                         // 20
    }                                                                                                     //
  });                                                                                                     //
};                                                                                                        //
                                                                                                          //
//---------                                                                                               //
                                                                                                          //
Ucare.load = function (key, callback) {                                                                   // 27
                                                                                                          //
  if (typeof uploadcare === "undefined") {                                                                // 29
    if (!key && Meteor.settings && Meteor.settings['public'] && Meteor.settings['public'].uploadcare && Meteor.settings['public'].uploadcare.publickey) key = Meteor.settings['public'].uploadcare.publickey;
                                                                                                          //
    if (key) {                                                                                            // 33
      window.UPLOADCARE_PUBLIC_KEY = key;                                                                 // 34
                                                                                                          //
      // Functions to run after the script tag has loaded                                                 //
      var loadCallback = function loadCallback() {                                                        // 33
        if (Object.prototype.toString.call(callback) === "[object Function]") {                           // 38
          if (typeof console !== "undefined") {                                                           // 39
            console.log("Uploadcare loaded");                                                             // 40
          }                                                                                               //
          callback();                                                                                     // 42
        }                                                                                                 //
      };                                                                                                  //
                                                                                                          //
      // If the script doesn't load                                                                       //
      var errorCallback = function errorCallback(error) {                                                 // 33
        if (typeof console !== "undefined") {                                                             // 48
          console.log(error);                                                                             // 49
        }                                                                                                 //
      };                                                                                                  //
                                                                                                          //
      var widgetVersion = "2.5.9";                                                                        // 53
                                                                                                          //
      if (Meteor.settings['public'].uploadcare.version) {                                                 // 55
        widgetVersion = Meteor.settings['public'].uploadcare.version;                                     // 56
      }                                                                                                   //
                                                                                                          //
      // Generate a script tag                                                                            //
      var script = document.createElement("script");                                                      // 33
      script.type = "text/javascript";                                                                    // 61
      script.src = "https://ucarecdn.com/widget/" + widgetVersion + "/uploadcare/uploadcare.full.min.js";
      script.onload = loadCallback;                                                                       // 63
      script.onerror = errorCallback;                                                                     // 64
                                                                                                          //
      // Load the script tag                                                                              //
      document.getElementsByTagName('head')[0].appendChild(script);                                       // 33
    } else {                                                                                              //
      if (typeof console !== "undefined") {                                                               // 70
        console.log("Couldn't load uploadcare - no public key set");                                      // 71
      }                                                                                                   //
    }                                                                                                     //
  } else {                                                                                                //
    if (typeof console !== "undefined") {                                                                 // 75
      console.log("Uploadcare already loaded");                                                           // 76
    }                                                                                                     //
  }                                                                                                       //
};                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/smalljoys_uploadcare/methods.js                                                               //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
if (Meteor.isServer) {                                                                                    // 1
  Future = Npm && Npm.require('fibers/future');                                                           // 2
                                                                                                          //
  Meteor.methods({                                                                                        // 4
                                                                                                          //
    addToMediaStorage: function () {                                                                      // 6
      function addToMediaStorage(image) {                                                                 // 6
        check(image, String);                                                                             // 7
                                                                                                          //
        this.unblock();                                                                                   // 9
                                                                                                          //
        var future = new Future();                                                                        // 11
                                                                                                          //
        var uuid = image.match(/[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89aAbB][a-f0-9]{3}-[a-f0-9]{12}/);  // 13
                                                                                                          //
        HTTP.call('PUT', 'https://api.uploadcare.com/files/' + uuid + '/storage/', {                      // 15
          headers: {                                                                                      // 18
            Accept: 'application/json',                                                                   // 19
            Date: new Date().toJSON(),                                                                    // 20
            Authorization: 'Uploadcare.Simple ' + Meteor.settings['public'].uploadcare.publickey + ':' + Meteor.settings['private'].uploadcare.secretkey
          }                                                                                               //
        }, function (err, res) {                                                                          //
          if (err) {                                                                                      // 25
            future['return'](err);                                                                        // 26
          } else {                                                                                        //
                                                                                                          //
            var filesize = res.data.size;                                                                 // 29
            future['return'](filesize);                                                                   // 30
          }                                                                                               //
        });                                                                                               //
                                                                                                          //
        return future.wait();                                                                             // 36
      }                                                                                                   //
                                                                                                          //
      return addToMediaStorage;                                                                           //
    }(),                                                                                                  //
                                                                                                          //
    removeFromMediaStorage: function () {                                                                 // 39
      function removeFromMediaStorage(image) {                                                            // 39
        check(image, String);                                                                             // 40
                                                                                                          //
        this.unblock();                                                                                   // 42
                                                                                                          //
        var future = new Future();                                                                        // 44
                                                                                                          //
        var uuid = image.match(/[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89aAbB][a-f0-9]{3}-[a-f0-9]{12}/);  // 46
                                                                                                          //
        HTTP.call('DELETE', 'https://api.uploadcare.com/files/' + uuid + '/', {                           // 48
          headers: {                                                                                      // 51
            Accept: 'application/json',                                                                   // 52
            Date: new Date().toJSON(),                                                                    // 53
            Authorization: 'Uploadcare.Simple ' + Meteor.settings['public'].uploadcare.publickey + ':' + Meteor.settings['private'].uploadcare.secretkey
          }                                                                                               //
        }, function (err, res) {                                                                          //
          if (err) {                                                                                      // 58
            future['return'](err);                                                                        // 59
          } else {                                                                                        //
                                                                                                          //
            var filesize = res.data.size;                                                                 // 62
            future['return'](filesize);                                                                   // 63
          }                                                                                               //
        });                                                                                               //
                                                                                                          //
        return future.wait();                                                                             // 69
      }                                                                                                   //
                                                                                                          //
      return removeFromMediaStorage;                                                                      //
    }()                                                                                                   //
                                                                                                          //
  });                                                                                                     //
}                                                                                                         //
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"policy.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/smalljoys_uploadcare/policy.js                                                                //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
//Uploadcare browser policy                                                                               //
BrowserPolicy.content.allowOriginForAll('https://ucarecdn.com');                                          // 2
BrowserPolicy.content.allowEval('https://ucarecdn.com');                                                  // 3
BrowserPolicy.content.allowScriptOrigin('https://ucarecdn.com');                                          // 4
BrowserPolicy.content.allowImageOrigin('https://ucarecdn.com');                                           // 5
                                                                                                          //
BrowserPolicy.content.allowOriginForAll('http://ucarecdn.com');                                           // 7
BrowserPolicy.content.allowEval('http://ucarecdn.com');                                                   // 8
BrowserPolicy.content.allowScriptOrigin('http://ucarecdn.com');                                           // 9
BrowserPolicy.content.allowImageOrigin('http://ucarecdn.com');                                            // 10
                                                                                                          //
//Blob URLS (camera)                                                                                      //
BrowserPolicy.content.allowImageOrigin("blob:");                                                          // 13
var constructedCsp = BrowserPolicy.content._constructCsp();                                               // 14
BrowserPolicy.content.setPolicy(constructedCsp + " media-src blob:;");                                    // 15
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/smalljoys:uploadcare/ucare.js");
require("./node_modules/meteor/smalljoys:uploadcare/methods.js");
require("./node_modules/meteor/smalljoys:uploadcare/policy.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['smalljoys:uploadcare'] = {}, {
  Ucare: Ucare
});

})();

//# sourceMappingURL=smalljoys_uploadcare.js.map
