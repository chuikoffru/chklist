var require = meteorInstall({"imports":{"api":{"checklists":{"collection.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/checklists/collection.js                                                                      //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Object.defineProperty(exports, '__esModule', {                                                               //
  value: true                                                                                                //
});                                                                                                          //
                                                                                                             //
var _meteorMongo = require('meteor/mongo');                                                                  //
                                                                                                             //
var ChList = new _meteorMongo.Mongo.Collection('checklists');                                                // 3
                                                                                                             //
exports.ChList = ChList;                                                                                     //
ChList.allow({                                                                                               // 5
  insert: function insert(userId, shop) {                                                                    // 6
    return true; //userId && shop.owner === userId;                                                          // 7
  },                                                                                                         //
  update: function update(userId, shop, fields, modifier) {                                                  // 9
    return true; //userId && shop.owner === userId;                                                          // 10
  },                                                                                                         //
  remove: function remove(userId, shop) {                                                                    // 12
    return true; // userId && shop.owner === userId;                                                         // 13
  }                                                                                                          //
});                                                                                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./publish","./collection",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/checklists/index.js                                                                           //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Object.defineProperty(exports, '__esModule', {                                                               //
  value: true                                                                                                //
});                                                                                                          //
                                                                                                             //
function _interopExportWildcard(obj, defaults) { var newObj = defaults({}, obj); delete newObj['default']; return newObj; }
                                                                                                             //
function _defaults(obj, defaults) { var keys = Object.getOwnPropertyNames(defaults); for (var i = 0; i < keys.length; i++) { var key = keys[i]; var value = Object.getOwnPropertyDescriptor(defaults, key); if (value && value.configurable && obj[key] === undefined) { Object.defineProperty(obj, key, value); } } return obj; }
                                                                                                             //
require('./publish');                                                                                        //
                                                                                                             //
var _collection = require('./collection');                                                                   //
                                                                                                             //
_defaults(exports, _interopExportWildcard(_collection, _defaults));                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"publish.js":["meteor/meteor","./collection",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/checklists/publish.js                                                                         //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _meteorMeteor = require('meteor/meteor');                                                                //
                                                                                                             //
var _collection = require('./collection');                                                                   //
                                                                                                             //
if (_meteorMeteor.Meteor.isServer) {                                                                         // 5
  _meteorMeteor.Meteor.publish('checklists', function () {                                                   // 6
    /*const selector = {                                                                                     //
      $or: [{                                                                                                //
        $and: [{                                                                                             //
          public: true                                                                                       //
        }, {                                                                                                 //
          public: {                                                                                          //
            $exists: true                                                                                    //
          }                                                                                                  //
        }]                                                                                                   //
      }, {                                                                                                   //
        $and: [{                                                                                             //
          owner: this.userId                                                                                 //
        }, {                                                                                                 //
          owner: {                                                                                           //
            $exists: true                                                                                    //
          }                                                                                                  //
        }]                                                                                                   //
      }]                                                                                                     //
    };*/                                                                                                     //
                                                                                                             //
    return _collection.ChList.find({});                                                                      // 27
  });                                                                                                        //
}                                                                                                            //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"reports":{"collection.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/reports/collection.js                                                                         //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Object.defineProperty(exports, '__esModule', {                                                               //
  value: true                                                                                                //
});                                                                                                          //
                                                                                                             //
var _meteorMongo = require('meteor/mongo');                                                                  //
                                                                                                             //
var Reports = new _meteorMongo.Mongo.Collection('reports');                                                  // 3
                                                                                                             //
exports.Reports = Reports;                                                                                   //
Reports.allow({                                                                                              // 5
  insert: function insert(userId, report) {                                                                  // 6
    return true;                                                                                             // 7
  },                                                                                                         //
  update: function update(userId, report, fields, modifier) {                                                // 9
    return true;                                                                                             // 10
  },                                                                                                         //
  remove: function remove(userId, report) {                                                                  // 12
    return true;                                                                                             // 13
  }                                                                                                          //
});                                                                                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./publish","./collection",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/reports/index.js                                                                              //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Object.defineProperty(exports, '__esModule', {                                                               //
  value: true                                                                                                //
});                                                                                                          //
                                                                                                             //
function _interopExportWildcard(obj, defaults) { var newObj = defaults({}, obj); delete newObj['default']; return newObj; }
                                                                                                             //
function _defaults(obj, defaults) { var keys = Object.getOwnPropertyNames(defaults); for (var i = 0; i < keys.length; i++) { var key = keys[i]; var value = Object.getOwnPropertyDescriptor(defaults, key); if (value && value.configurable && obj[key] === undefined) { Object.defineProperty(obj, key, value); } } return obj; }
                                                                                                             //
require('./publish');                                                                                        //
                                                                                                             //
var _collection = require('./collection');                                                                   //
                                                                                                             //
_defaults(exports, _interopExportWildcard(_collection, _defaults));                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"publish.js":["meteor/meteor","./collection",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/reports/publish.js                                                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _meteorMeteor = require('meteor/meteor');                                                                //
                                                                                                             //
var _collection = require('./collection');                                                                   //
                                                                                                             //
if (_meteorMeteor.Meteor.isServer) {                                                                         // 5
  _meteorMeteor.Meteor.publish('reports', function (options) {                                               // 6
    return _collection.Reports.find({});                                                                     // 7
  });                                                                                                        //
                                                                                                             //
  _meteorMeteor.Meteor.publish('fullReports', function (options) {                                           // 10
    var selector = {};                                                                                       // 11
    return _collection.Reports.find(selector, options);                                                      // 12
  });                                                                                                        //
}                                                                                                            //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"shops":{"collection.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/shops/collection.js                                                                           //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Object.defineProperty(exports, '__esModule', {                                                               //
  value: true                                                                                                //
});                                                                                                          //
                                                                                                             //
var _meteorMongo = require('meteor/mongo');                                                                  //
                                                                                                             //
var Shops = new _meteorMongo.Mongo.Collection('shops');                                                      // 3
                                                                                                             //
exports.Shops = Shops;                                                                                       //
Shops.allow({                                                                                                // 5
  insert: function insert(userId, shop) {                                                                    // 6
    return true; //userId && shop.owner === userId;                                                          // 7
  },                                                                                                         //
  update: function update(userId, shop, fields, modifier) {                                                  // 9
    return true; //userId && shop.owner === userId;                                                          // 10
  },                                                                                                         //
  remove: function remove(userId, shop) {                                                                    // 12
    return true; // userId && shop.owner === userId;                                                         // 13
  }                                                                                                          //
});                                                                                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./publish","./collection",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/shops/index.js                                                                                //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Object.defineProperty(exports, '__esModule', {                                                               //
  value: true                                                                                                //
});                                                                                                          //
                                                                                                             //
function _interopExportWildcard(obj, defaults) { var newObj = defaults({}, obj); delete newObj['default']; return newObj; }
                                                                                                             //
function _defaults(obj, defaults) { var keys = Object.getOwnPropertyNames(defaults); for (var i = 0; i < keys.length; i++) { var key = keys[i]; var value = Object.getOwnPropertyDescriptor(defaults, key); if (value && value.configurable && obj[key] === undefined) { Object.defineProperty(obj, key, value); } } return obj; }
                                                                                                             //
require('./publish');                                                                                        //
                                                                                                             //
var _collection = require('./collection');                                                                   //
                                                                                                             //
_defaults(exports, _interopExportWildcard(_collection, _defaults));                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"publish.js":["meteor/meteor","./collection",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/shops/publish.js                                                                              //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _meteorMeteor = require('meteor/meteor');                                                                //
                                                                                                             //
var _collection = require('./collection');                                                                   //
                                                                                                             //
if (_meteorMeteor.Meteor.isServer) {                                                                         // 5
  _meteorMeteor.Meteor.publish('shops', function () {                                                        // 6
    /*const selector = {                                                                                     //
      $or: [{                                                                                                //
        $and: [{                                                                                             //
          public: true                                                                                       //
        }, {                                                                                                 //
          public: {                                                                                          //
            $exists: true                                                                                    //
          }                                                                                                  //
        }]                                                                                                   //
      }, {                                                                                                   //
        $and: [{                                                                                             //
          owner: this.userId                                                                                 //
        }, {                                                                                                 //
          owner: {                                                                                           //
            $exists: true                                                                                    //
          }                                                                                                  //
        }]                                                                                                   //
      }]                                                                                                     //
    };*/                                                                                                     //
                                                                                                             //
    return _collection.Shops.find({});                                                                       // 27
  });                                                                                                        //
}                                                                                                            //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"users":{"index.js":["meteor/meteor",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/users/index.js                                                                                //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _meteorMeteor = require('meteor/meteor');                                                                //
                                                                                                             //
_meteorMeteor.Meteor.users.allow({                                                                           // 3
  insert: function insert(userId) {                                                                          // 4
    return true;                                                                                             // 5
  },                                                                                                         //
  update: function update(userId, fields, modifier) {                                                        // 7
    return true;                                                                                             // 8
  }                                                                                                          //
});                                                                                                          //
                                                                                                             //
if (_meteorMeteor.Meteor.isServer) {                                                                         // 12
  _meteorMeteor.Meteor.publish('users', function () {                                                        // 13
    return _meteorMeteor.Meteor.users.find({});                                                              // 14
  });                                                                                                        //
                                                                                                             //
  _meteorMeteor.Meteor.publish('usersList', function () {                                                    // 17
    return _meteorMeteor.Meteor.users.find({                                                                 // 18
      roles: { $in: "user" }                                                                                 // 19
    });                                                                                                      //
  });                                                                                                        //
}                                                                                                            //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},"server":{"api.js":["meteor/meteor","../imports/api/shops",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/api.js                                                                                             //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _meteorMeteor = require('meteor/meteor');                                                                //
                                                                                                             //
var _importsApiShops = require('../imports/api/shops');                                                      //
                                                                                                             //
_meteorMeteor.Meteor.methods({                                                                               // 4
  getUsers: function getUsers() {                                                                            // 5
    return _meteorMeteor.Meteor.users();                                                                     // 6
  },                                                                                                         //
  getShops: function getShops() {                                                                            // 8
    return _importsApiShops.Shops.find({});                                                                  // 9
  }                                                                                                          //
});                                                                                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"checklists.js":["meteor/meteor","../imports/api/checklists",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/checklists.js                                                                                      //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _meteorMeteor = require('meteor/meteor');                                                                //
                                                                                                             //
var _importsApiChecklists = require('../imports/api/checklists');                                            //
                                                                                                             //
_meteorMeteor.Meteor.methods({                                                                               // 4
  setPosition: function setPosition(id, item, position) {                                                    // 5
    _importsApiChecklists.ChList.update({ shop_id: id, 'questions.title': item.title }, {                    // 6
      $inc: {                                                                                                // 7
        'questions.$.position': position                                                                     // 8
      }                                                                                                      //
    });                                                                                                      //
  }                                                                                                          //
});                                                                                                          //
                                                                                                             //
var ChListApi = new Restivus({                                                                               // 14
  useDefaultAuth: false,                                                                                     // 15
  prettyJson: true                                                                                           // 16
});                                                                                                          //
                                                                                                             //
ChListApi.addRoute('checklists', { authRequired: false }, {                                                  // 19
  get: function get() {                                                                                      // 20
    return _importsApiChecklists.ChList.find({}).fetch();                                                    // 21
  }                                                                                                          //
});                                                                                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"shops.js":["meteor/meteor","../imports/api/shops","../imports/api/checklists",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/shops.js                                                                                           //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _meteorMeteor = require('meteor/meteor');                                                                //
                                                                                                             //
var _importsApiShops = require('../imports/api/shops');                                                      //
                                                                                                             //
var _importsApiChecklists = require('../imports/api/checklists');                                            //
                                                                                                             //
var ShopsApi = new Restivus({                                                                                // 5
  useDefaultAuth: false,                                                                                     // 6
  prettyJson: true                                                                                           // 7
});                                                                                                          //
                                                                                                             //
ShopsApi.addRoute('shops', { authRequired: false }, {                                                        // 10
  get: function get() {                                                                                      // 11
    return _importsApiShops.Shops.find({}).fetch();                                                          // 12
  }                                                                                                          //
});                                                                                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"users.js":["meteor/meteor","meteor/accounts-base","meteor/alanning:roles",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/users.js                                                                                           //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _meteorMeteor = require('meteor/meteor');                                                                //
                                                                                                             //
var _meteorAccountsBase = require('meteor/accounts-base');                                                   //
                                                                                                             //
var _meteorAlanningRoles = require('meteor/alanning:roles');                                                 //
                                                                                                             //
_meteorMeteor.Meteor.methods({                                                                               // 5
  addNewUser: function addNewUser(data) {                                                                    // 6
                                                                                                             //
    var id = undefined;                                                                                      // 8
                                                                                                             //
    if (_meteorAlanningRoles.Roles.userIsInRole(_meteorMeteor.Meteor.userId(), 'admin')) {                   // 10
      console.log("You are admin");                                                                          // 12
      id = _meteorAccountsBase.Accounts.createUser(data);                                                    // 13
                                                                                                             //
      if (id) {                                                                                              // 15
        _meteorAlanningRoles.Roles.setUserRoles(id, data.roles);                                             // 16
        console.log('YES');                                                                                  // 17
      } else {                                                                                               //
        console.log('NO');                                                                                   // 19
      }                                                                                                      //
    } else {                                                                                                 //
      id = null;                                                                                             // 23
      console.log('No permission');                                                                          // 24
    }                                                                                                        //
                                                                                                             //
    return id;                                                                                               // 27
  },                                                                                                         //
  getUserByEmail: function getUserByEmail(email) {                                                           // 29
    return _.pick(_meteorAccountsBase.Accounts.findUserByEmail(email), '_id', 'profile', 'emails', 'roles');
  }                                                                                                          //
});                                                                                                          //
                                                                                                             //
var UserApi = new Restivus({                                                                                 // 34
  useDefaultAuth: false,                                                                                     // 35
  prettyJson: true                                                                                           // 36
});                                                                                                          //
                                                                                                             //
UserApi.addRoute('users', { authRequired: false }, {                                                         // 39
  get: function get() {                                                                                      // 40
    return _meteorMeteor.Meteor.users.find({}, {                                                             // 41
      fields: { services: 0, createdAt: 0, 'emails.verified': 0 }                                            // 42
    }).fetch();                                                                                              //
  }                                                                                                          //
});                                                                                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"main.js":["meteor/meteor","meteor/accounts-base","../imports/api/shops","../imports/api/reports","../imports/api/users","../imports/api/checklists",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/main.js                                                                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _meteorMeteor = require('meteor/meteor');                                                                //
                                                                                                             //
var _meteorAccountsBase = require('meteor/accounts-base');                                                   //
                                                                                                             //
var _importsApiShops = require('../imports/api/shops');                                                      //
                                                                                                             //
require('../imports/api/reports');                                                                           //
                                                                                                             //
require('../imports/api/shops');                                                                             //
                                                                                                             //
require('../imports/api/users');                                                                             //
                                                                                                             //
require('../imports/api/checklists');                                                                        //
                                                                                                             //
_meteorMeteor.Meteor.startup(function () {                                                                   // 10
                                                                                                             //
  var userId = undefined;                                                                                    // 12
                                                                                                             //
  //Заполняем данные администратора                                                                          //
  if (_meteorMeteor.Meteor.users.find({}).count() == 0) {                                                    // 15
                                                                                                             //
    userId = _meteorAccountsBase.Accounts.createUser({                                                       // 17
      "username": "admin",                                                                                   // 18
      "email": "admin@admin.ru",                                                                             // 19
      "password": "12345679"                                                                                 // 20
    });                                                                                                      //
                                                                                                             //
    Roles.addUsersToRoles(userId, 'admin');                                                                  // 23
  }                                                                                                          //
                                                                                                             //
  //Заполняем данные магазинов                                                                               //
  if (_importsApiShops.Shops.find().count() === 0) {                                                         // 27
    var shops = [{                                                                                           // 28
      'name': 'Камчадалочка',                                                                                // 29
      'address': 'ул. Владивостокская, 47',                                                                  // 30
      "owner": userId,                                                                                       // 31
      'active': 1                                                                                            // 32
    }, {                                                                                                     //
      'name': 'ТЦ Евразия',                                                                                  // 34
      'address': 'ул. Кавказская, 49',                                                                       // 35
      "owner": userId,                                                                                       // 36
      'active': 1                                                                                            // 37
    }, {                                                                                                     //
      'name': 'ТЦ Вега',                                                                                     // 39
      'address': 'ул. Пограничная, 13',                                                                      // 40
      "owner": userId,                                                                                       // 41
      'active': 1                                                                                            // 42
    }, {                                                                                                     //
      'name': 'Елизово',                                                                                     // 44
      'address': 'ул. Ленина, 21',                                                                           // 45
      "owner": userId,                                                                                       // 46
      'active': 1                                                                                            // 47
    }];                                                                                                      //
                                                                                                             //
    shops.forEach(function (shop) {                                                                          // 50
      _importsApiShops.Shops.insert(shop);                                                                   // 51
    });                                                                                                      //
  }                                                                                                          //
});                                                                                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/api.js");
require("./server/checklists.js");
require("./server/shops.js");
require("./server/users.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
